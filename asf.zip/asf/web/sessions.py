from selenium import webdriver

driver = webdriver.Firefox()
driver.quit()

